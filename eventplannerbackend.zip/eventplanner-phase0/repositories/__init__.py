"""Repository layer for data access"""
from .user_repository import UserRepository

__all__ = ['UserRepository']
